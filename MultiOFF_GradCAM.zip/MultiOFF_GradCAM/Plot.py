"source": [
    "import matplotlib.pyplot as plt\n",
    "from torchcam.utils import overlay_mask\n",
    "\n",
    "fig = plt.figure(figsize=(3, 4))\n",
    "# Resize the CAM and overlay it\n",
    "\n",
    "print('1 : ', activation_map[0].squeeze(0).shape)\n",
    "print('2 : ', img.shape)\n",
    "\n",
    "\n",
    "result = overlay_mask(to_pil_image(img), to_pil_image(activation_map[0].squeeze(0), mode='F'), alpha=0.5)\n",
    "# Display it\n",
    "plt.imshow(result); plt.axis('off'); plt.tight_layout(); plt.show()\n",
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "09e05601",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.13"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}